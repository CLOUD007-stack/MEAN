const morgan = require('morgan')
const express = require("express");
const app = express(); // Creating express server
//Creating web server
const http = require('http');
const server = http.Server();
const cors = require('cors');
var { expressjwt: expressJwt } = require('express-jwt');
// const {expressJwt} = require('express-jwt');
const jwt = require('jsonwebtoken');
const router = require('./src/router/router'); //Importing router module
//ENV Variables
const path = require('path'); 
require('dotenv').config({ path: path.join(__dirname, '.env') });

// console.log("BASEDIR",__dirname);

app.use(express.urlencoded({ extended: false }));   // parse URL encoded data
app.use(express.json());   // parse JSON object

app.use(morgan('tiny'));  // API details

app.use(cors());
// CORS middleware
const allowCrossDomain = function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', '*');
  res.header('Access-Control-Allow-Headers', '*');
  res.header('Access-Control-Expose-Headers', '*');
  next();
}
app.use(allowCrossDomain);

// Using express-jwt to authenticate each API
// By default it takes Authorization: Bearer <token>
// let secret = process.env.JWT_SECRET_KEY;
// console.log("SECRET KEY",secret);
// app.use(expressJwt({ secret: process.env.JWT_SECRET_KEY, algorithms: ['HS256'] })
//   .unless({
//     path: ['/api/post/login']  // This allows access to /api/post/login without token authentication
//   })
// );

app.use('/escoCustApi',router);  // Using router module
// app.use('/',router);  // Using router module


// app.get('/', (req, res) => {
//   res.send('ESCO Customer Onboarding Backend');
// })

const port = process.env.PORT;
console.log("PORT",port);

app.listen(port, err => {
    if (err) return console.log(`Cannot Listen on PORT: ${port}`);
    console.log(`Server is Listening on: http://localhost:${port}/`);
});