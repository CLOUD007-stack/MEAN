const express = require("express");
const router = express.Router();
const controller = require('../controller/controller');
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/admin');
const upload = require('../config/upload.file');



router.get('/', controller.renderBackendHome);


/** 
 * COMMON APIs  *******************************************************************************************
 */

/*** Home Page API  ****/
router.post('/post/demodownlaod', controller.post_demodownload);


/*** Register Page API  ****/
router.post('/post/register', controller.post_register);


/*** Login Page API ****/
router.post('/post/login', controller.post_login);
router.post('/post/email', controller.post_email);
router.post('/post/send/link', controller.post_sendlink);
router.post('/validate/resetlink', controller.validate_resetlink);
router.post('/reset/password', controller.reset_password);


/** 
 * END of COMMON APIs  *******************************************************************************************
 */


/** 
 * ADMIN APIs  *******************************************************************************************
 */

/*** Services Page API ****/
// router.get('/get/services', controller.get_services);
router.post('/post/services', auth, controller.post_services);
// router.post('/edit/services', controller.edit_services);
// router.post('/delete/services', controller.delete_services);


/*** Group Page API ****/
router.post('/post/group', auth, controller.post_group);


/*** Query Category Page API ****/
router.post('/post/query_category', auth, controller.post_query_category);
router.post('/post/query_subcategory', auth, controller.post_query_subcategory);


/** Add Customer Page API */
router.get('/get/customer_details', auth, controller.get_addCustomers);
router.post('/post/customer_details', auth, upload.array('attachment'), controller.post_addCustomers);
router.post('/edit/customer_details', auth, upload.array('attachment'), controller.edit_customers);
// router.put('/edit/customer_details', auth, controller.edit_customers);
// router.post('/delete/customer_details', controller.delete_addCustomers);


/** Add Customer Service Page API */
router.get('/get/customer/service', auth, controller.get_cust_services);
router.post('/post/customer/service', auth, controller.post_custservice);
router.put('/edit/customer/service', auth, controller.edit_custservice);


/** Add User Page API */
router.get('/get/user', auth, controller.get_user);
router.post('/post/user', auth, controller.post_user);
router.put('/edit/user', auth, controller.edit_user);
router.post('/send/mail', auth, controller.send_mail);


/** Download File API */
router.get('/get/attachment', controller.get_attachment); 


/**
 *  API
 */
router.get('/get/details', controller.get_details);        //GET          [services, customer, group]
router.put('/edit/details', auth, controller.edit_details);       //EDIT        [services, customer, group]
router.delete('/delete/details', auth, controller.delete_details);   //DELETE   [services, customer, group]


/** 
 * END of ADMIN APIs  ****************************************************************************************
 */


/** 
 * CUSTOMER APIs  *******************************************************************************************
 */

router.get('/get/customer/details', controller.get_customer_details);  


/** Customer Query API */
router.get('/get/customer_query', controller.get_customer_query); 
router.post('/post/customer_query', auth, upload.array('attachment'), controller.post_customer_query);
router.post('/post/query_description', auth, controller.post_query_description);
router.get('/get/customer_queries', controller.get_customer_queries); 
router.post('/post/query_status', auth, controller.post_query_status);

 


module.exports = router;