const moment = require('moment');
const nodemailer = require("nodemailer");


function convertUTCtoLocalDate(time) {
    // 2022-09-07T18:30:00.000Z  -->  09/08/2022
    return new Date(time).toLocaleDateString('en-US'); 
}

function changeDateFormat(date, format){
    // console.log("format",format);
    return moment(date).format(format); //Sep 3rd 22
}

// SEND MAIL FUNCTION
async function sendMail(emailOptions) {
    // NODE MAILER - TO SEND LINK TO EMAIL
    // Create transporter object 
    let transporter = nodemailer.createTransport({
        tls: {
            rejectUnauthorized: false
        },
        host: "mail.tpc.co.in", // SMTP server
        port: 25,
        secure: false, // true for 465, false for other ports
    });

    transporter.verify(function (error, success) {
        if (error) {
            console.log('ERROR: ', error);
        } else {
            console.log('Server is ready to take our messages');
        }
    });

    // console.log("transporter", transporter);
    let mailOptions = emailOptions;
    console.log("emailOptions", emailOptions);
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log("FAILED MAIL", error);
            transporter.close();
            return false;
        }
        else {
            console.log('MAIL SENT');
            // transporter.close();
            return true;
        }

    });

}


module.exports = {
    convertUTCtoLocalDate,
    changeDateFormat,
    sendMail
}