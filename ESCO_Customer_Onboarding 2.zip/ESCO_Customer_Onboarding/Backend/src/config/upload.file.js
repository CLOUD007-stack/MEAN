const multer = require("multer");
const maxSize = 2 * 1024 * 1024;
const path = require('path');

let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    console.log("__dirname", __dirname);
    
    let oneStepBack = path.join(__dirname, '../');
    console.log("oneStepBack",oneStepBack);  //move one step back from current directory
    cb(null, oneStepBack + "assets/attachments/");
  },
  filename: (req, file, cb) => {
    console.log("file", file, "file.originalname", file.originalname);
    cb(null, file.originalname);
  },
});

let uploadFile = multer({
  storage: storage,
  limits: { fileSize: maxSize },
});
// }).single("file");

// let uploadFileMiddleware = util.promisify(uploadFile);
module.exports = uploadFile;