const {Pool} = require('pg')

// const pool = new Pool({
//     host: '172.16.208.211',
//     port: 5432,
//     database: 'ESCO_Customer_Onboarding',
//     user: 'esco_cust_onboard',
//     password: 'eco',
// });

const pool = new Pool({
    host: '100.70.74.202',
    port: 5432,
    database: 'esco_customer_onboarding',
    user: 'esco_cust_write',
    password: 'TP123',
});

// if(pool){ 
//     console.log('DATABASE Connection Successful');
// }
// else{
//     console.log('Cant connect to db, Check ur db connection');
// }

pool.connect(err=>{
    if(err) console.log('Cant connect to db, Check ur db connection');
    console.log('DATABASE Connection Successful');
})

module.exports={pool}