// const { query } = require('express');
const { pool } = require('../config/database.postgres');
const func = require('../functions/func');


async function getCustomerServices(req, res) {

    const customerid = req.query['customerid'];

    try {
        const result = await pool.query('SELECT * FROM customer_onboarding.customer_service WHERE customer_id=$1', [customerid]);
        // console.log("GET CUST SERVICES", result.rows);
        if (result.rowCount == 0) {
            console.log(result.rowCount);
            return "No Data Available";
        }
        else {
            // Extracting service & partner from service id
            for (let row = 0; row < result.rows.length; row++) {
                const serviceid = result.rows[row].service_id;

                //function call for date format convert
                // Subscription start date
                // result.rows[row].subscription_st_dt = func.changeDateFormat(result.rows[row].subscription_st_dt, "Do MMM YY");

                // // Subscription end date
                // result.rows[row].subscription_end_dt = func.changeDateFormat(result.rows[row].subscription_end_dt, "Do MMM YY");


                const queryservice = await pool.query('SELECT service_name, partner FROM customer_onboarding.services WHERE service_id=$1', [serviceid]);
                let service = queryservice.rows[0].service_name;
                let partner = queryservice.rows[0].partner;
                result.rows[row]['service'] = service;
                result.rows[row]['partner'] = partner;
            }
            // console.log("GET CUST SERVICES result.rows", result.rows);
            return result.rows;
        }
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}

async function postcustServices(req, res) {

    console.log("POST CUST SERVICES", req.body);

    try {
        const { servicename, partner, customerid, substartdate, noofdays, subenddate, status, agreementno, pono, povalue } = req.body;

        const query_serviceid = await pool.query('SELECT service_id FROM customer_onboarding.services WHERE service_name=$1 AND partner=$2', [servicename, partner]);
        const serviceid = query_serviceid.rows[0].service_id;
        console.log("service id", serviceid, customerid);
        
        // CHECK FOR ALREADY PRESENT DATA [BASIS -> service, partner, customer]

        // Fetching service_id from customer service table to check if already present
        const query_serviceidCS = await pool.query('SELECT service_id,customer_id,subscription_st_dt,no_of_days FROM customer_onboarding.customer_service');

        for (let row = 0; row < query_serviceidCS.rows.length; row++) {
            const serviceidCS = query_serviceidCS.rows[row].service_id;
            const customeridCS = query_serviceidCS.rows[row].customer_id;

            console.log("Data Already Present sid",serviceidCS,customeridCS) ;
            // matching for serviceid if present already in customer service table
            if(serviceidCS == serviceid && customeridCS == customerid && substartdate == query_serviceidCS.rows[row].subscription_st_dt && noofdays == query_serviceidCS.rows[row].no_of_days){
                console.log("Data Already Present") ;
                return "Data Already Present";
            }
        }

        const result = await pool.query('INSERT INTO customer_onboarding.customer_service (customer_id,subscription_st_dt,no_of_days,subscription_end_dt,status,agreement_no,po_no,po_value,service_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)', [customerid, substartdate, noofdays, subenddate, status, agreementno, pono, povalue, serviceid]);
        console.log("POST CUST SERVICES result", result);


        return result.command;
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }

}

async function editcustServices(req, res) {

    console.log("EDIT CUST SERVICES", req.body);

    try {
        const { servicename, partner, substartdate, noofdays, subenddate, status, agreementno, pono, povalue, customerid, csid } = req.body;
        
        const query_serviceid = await pool.query('SELECT service_id FROM customer_onboarding.services WHERE service_name=$1 AND partner=$2', [servicename, partner]);
        const serviceid = query_serviceid.rows[0].service_id;
        console.log("no_of_days", noofdays);

        const result = await pool.query('UPDATE customer_onboarding.customer_service SET customer_id=$1,subscription_st_dt=$2,no_of_days=$3,subscription_end_dt=$4,status=$5,agreement_no=$6,po_no=$7,po_value=$8,service_id=$9 WHERE cs_id=$10', [customerid, substartdate, noofdays, subenddate, status, agreementno, pono, povalue, serviceid, csid]);
        console.log("EDIT CUST SERVICES result", result);


        return result.command;
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }

}



module.exports = {
    getCustomerServices,
    postcustServices,
    editcustServices
}