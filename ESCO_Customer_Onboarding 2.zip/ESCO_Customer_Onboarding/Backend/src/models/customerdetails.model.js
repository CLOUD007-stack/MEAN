const { pool } = require('../config/database.postgres');

async function getCustomerDetails(req, res) {

    const customerid = req.query['customerid'];
    console.log("GET CUST DETAILS customerid", customerid);

    try {
        // QUERY TO FETCH services OF PARTICULAR CUSTOMER
        const result = await pool.query('SELECT * FROM customer_onboarding.customer_service WHERE customer_id=$1', [customerid]);
        console.log("GET CUST DETAILS result", result.rows);
        
        // QUERY TO FETCH users OF PARTICULAR CUSTOMER
        const result1 = await pool.query('SELECT uid FROM customer_onboarding.user WHERE customer_id=$1', [customerid]);
        console.log("GET CUST DETAILS result1", result1.rows);

        if (result.rowCount == 0) {
            console.log("rowCount", result.rowCount);
            return "No Data Available";
        }
        else {
            // GETTING USERS OF PARTICULAR SERVICES OF PARTICULAR CUSTOMER
            for(let s=0; s<result.rows.length; s++) {
                let serviceid = result.rows[s].service_id;
                console.log("serviceid", serviceid, customerid);

                // QUERY TO FETCH SERVICE NAME & URL LINK
                const queryServiceURL = await pool.query(`SELECT service_name, url_link FROM customer_onboarding.services WHERE service_id=$1`, [serviceid]); 
                console.log("queryServiceURL", queryServiceURL.rows);

                result.rows[s]['servicename'] = queryServiceURL.rows[0].service_name;
                result.rows[s]['serviceurl'] = queryServiceURL.rows[0].url_link;


                // QUERY TO FETCH USER COUNT FOR PARTICULAR SERVICE OF PARTICULAR CUSTOMER
                const queryUserCount = await pool.query(`SELECT COUNT(uid) FROM customer_onboarding.user_service WHERE service_id=$1 AND uid IN (SELECT uid FROM customer_onboarding.user WHERE customer_id=$2);`, [serviceid, customerid]);
                console.log("COUNT(uid)", queryUserCount.rows[0].count);

                result.rows[s]['usercount'] = queryUserCount.rows[0].count;
            }

        }
        // console.log("FINAL result", result.rows);
        return result.rows;
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}


module.exports = {
    getCustomerDetails
}