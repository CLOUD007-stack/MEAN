const { pool } = require('../config/database.postgres');

async function postQueryCategory(req, res) {

    console.log("POST Query Category", req.body);
    try {
        const { category, subcategories } = req.body;
        console.log("POST Query subcategories", subcategories);

        // CHECK FOR ALREADY PRESENT DATA [BASIS -> category,subcategory]
        // ** QUERY TO FETCH Query Categories TABLE DATA 
        const queries = await pool.query(`SELECT * FROM customer_onboarding.query_categories`);
        // console.log("post query", queries.rows);
        for (let i = 0; i < queries.rows.length; i++) {
            for (let j = 0; j < subcategories.length; j++) {
                if (category == queries.rows[i].category && subcategories[j].subcategory == queries.rows[i].subcategory) {
                    console.log("Data Already Present");
                    return "Data Already Present";
                }
            }
        }

        var result;
        for (let i = 0; i < subcategories.length; i++) {
            const subcategory = subcategories[i];
            console.log("subcategory", subcategory, category)
            result = await pool.query('INSERT INTO customer_onboarding.query_categories (category,subcategory) VALUES ($1,$2)', [category, subcategory]);
            console.log("POST Query Category result", result);
        }
        console.log("POST Query Category command", result.command);
        // return result.command;
    }
    catch (error) {
        console.log("ERROR group", error.message);
        return "Unsuccessful";
    }
}


async function postQuerySubCategory(req, res) {

    console.log("POST Query subCategory", req.body);
    try {
        const { subcategory } = req.body;

        // CHECK FOR ALREADY PRESENT DATA [BASIS -> subcategory]
        // ** QUERY TO FETCH Query Sub-Category TABLE DATA 
        const queries = await pool.query(`SELECT * FROM customer_onboarding.query_subcategory`);
        console.log("post query", queries.rows);
        for (let g = 0; g < queries.rows.length; g++) {
            if (subcategory == queries.rows[g].subcategory) {
                console.log("Data Already Present");
                return "Data Already Present";
            }
        }

        const result = await pool.query('INSERT INTO customer_onboarding.query_subcategory (subcategory) VALUES ($1)', [subcategory]);
        // console.log("POST Query subCategory result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR group", error.message);
        return "Unsuccessful";
    }
}

module.exports = {
    postQueryCategory,
    postQuerySubCategory
}