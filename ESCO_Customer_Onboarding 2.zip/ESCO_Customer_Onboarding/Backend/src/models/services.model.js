const { pool } = require('../config/database.postgres');
// const Joi = require('joi');

// async function getServices(req, res) {

//     try {
//         const result = await pool.query('SELECT * FROM customer_onboarding.services');
//         // console.log("GET SERVICES", result.rows);
//         if (result.rowCount == 0) {
//             console.log(result.rowCount);
//             return "No Data Available";
//         }
//         else return result.rows;
//     }
//     catch (error) {
//         console.log("ERROR get", error.message);
//         return "Unsuccessful";
//     }
// }

// Client Input service validation
// async function validateService(req) {

//     // console.log("Validate SERVICES", req.body);
//     const schema = Joi.object({
//         // serviceid: Joi.string().min(3).required(),
//         servicename: Joi.string().min(3).required(),
//         partner: Joi.string().min(3).required(),
//         serviceurl: Joi.string().uri()
//     });

//     const isValid = schema.validate(req.body);
//     // console.log("VALIDITY", isValid);
//     return isValid;
// }

async function postServices(req, res) {

    console.log("POST SERVICES", req.body);
    try {
        const { servicename, partner, serviceurl } = req.body;

        // CHECK FOR ALREADY PRESENT DATA [BASIS -> servicename, partner]
        // ** QUERY TO FETCH SERVICES TABLE DATA 
        const services = await pool.query(`SELECT * FROM customer_onboarding.services`);
        console.log("post services", services.rows);
        for(let s=0; s<services.rows.length; s++) {
            if(servicename == services.rows[s].service_name && partner == services.rows[s].partner) {
                console.log("Data Already Present") ;
                return "Data Already Present";
            }
        }
        const result = await pool.query('INSERT INTO customer_onboarding.services (service_name,partner,url_link) VALUES ($1, $2, $3)', [servicename, partner, serviceurl]);
        // console.log("POST SERVICES result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }
}

// async function editServices(req, res) {

//     console.log("EDIT SERVICES", req.body);
//     try {
//         const { servicename, partner, serviceurl, serviceid } = req.body;
//         const result = await pool.query('UPDATE customer_onboarding.services SET service_name=$1, partner=$2, url_link=$3 WHERE service_id=$4', [servicename, partner, serviceurl, serviceid]);
//         console.log("EDIT SERVICES result", result);
//         return result.command;
//     }
//     catch (error) {
//         console.log("ERROR edit", error.message);
//         return "Unsuccessful";
//     }

// }

// async function deleteServices(req, res) {

//     // console.log("DELETE SERVICES", req.body);
//     try {
//         const { serviceid } = req.body;
//         const result = await pool.query('DELETE FROM customer_onboarding.services WHERE service_id=$1', [serviceid]);
//         // console.log("DELETE SERVICES result", result);
//         return result.command;
//     }
//     catch (error) {
//         console.log("ERROR delete", error.message);
//         return "Unsuccessful";
//     }

// }


module.exports = {
    // getServices,
    // validateService,
    postServices,
    // editServices,
    // deleteServices
}