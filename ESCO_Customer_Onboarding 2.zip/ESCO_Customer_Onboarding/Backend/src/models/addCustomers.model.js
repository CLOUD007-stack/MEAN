const { pool } = require('../config/database.postgres');
const Joi = require('joi');


// TO CONVERT NULL STRING TO NULL OBJECT
function formControlCheck(object) {
    console.log("OBJECT", object)
    for (const property in object) {
        // console.log(`${property}: ${object[property]}`);
        if (object[property] == 'null' || object[property] == '') {
            console.log("NULL");
            object[property] = null;
        }
    }
    return object;
}


//Get Customer 
async function getCustomers(req, res) {

    try {
        //** QUERY to fetch customer details */
        const result = await pool.query('SELECT * FROM customer_onboarding.customer_details');
        // console.log("GET CUSTOMER DETAILS", result.rows);
        if (result.rowCount == 0) {
            console.log(result.rowCount);
            return "No Data Available";
        }
        else {
            //** QUERY to fetch count of customer services and users */
            for (let c = 0; c < result.rowCount; c++) {
                const customerid = result.rows[c].customer_id;
                const groupid = result.rows[c].group_id;
                // console.log("customerid", customerid);

                const query1 = await pool.query(`SELECT count(service_id) FROM customer_onboarding.customer_service WHERE customer_id=$1`, [customerid]);
                // console.log("query1", query1.rows);

                const query2 = await pool.query(`SELECT count(uid) FROM customer_onboarding.user WHERE customer_id=$1`, [customerid]);
                // console.log("query2", query2.rows[0].count);

                //** QUERY to fetch groupid acc to group name from groups table **//
                const query3 = await pool.query('SELECT group_name FROM customer_onboarding.groups WHERE group_id=$1', [groupid]);
                // console.log("group_id", query3.rows);
                if (query3.rows.length) group_name = query3.rows[0].group_name;
                else group_name = '';
                // const group_name = query3.rows[0].group_name;

                // console.log("group_name", group_name);

                result.rows[c]['servicecount'] = query1.rows[0].count;
                result.rows[c]['usercount'] = query2.rows[0].count;
                result.rows[c]['group_name'] = group_name;
            }
            // console.log("GET CUSTOMER", result.rows);
            return result.rows;
        }
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}

//Add Customer 
async function postaddCustomers(req, res) {

    console.log("POST Add Customer", req.body);
    formControlCheck(req.body);  // To convert null string to null object
    console.log("POST Add Customer", req.body);
    // const { sapcustomerid, companyname, primaryname, primaryemail, secondaryemail, primarycontact, secondarycontact, siteaddress, gstno, panno, attachment, groupcompanyname, customerid } = req.body;


    try {
        // CHECK WHETHER ATTACHMENT IS PRESENT
        console.log("req.files:", req.files.length)
        if (req.files.length) {
            // console.log("req.files", req.files);
            var customerdoc = req.files[0].path;
        }
        else {
            var customerdoc = null;
        }
        // console.log("attachment", customerdoc);

        var { sapcustomerid, companyname, primaryname, primaryemail, secondaryemail, primarycontact, secondarycontact, siteaddress, gstno, panno, groupcompanyname, customerid } = req.body;
        console.log("customerid", customerid);
        

        // DATA ALREADY PRESENT  - (BASIS -> email || contact)

        // Fetching conatct & email_id from customer_details table to check if already present
        const query_emailcontact = await pool.query('SELECT primary_email,primary_contact_no FROM customer_onboarding.customer_details');
        // console.log("Qcs_id", query_email);
        for (let row = 0; row < query_emailcontact.rows.length; row++) {
            if (primaryemail == query_emailcontact.rows[row].primary_email || primarycontact == query_emailcontact.rows[row].primary_contact_no) {
                console.log("Data Already Present");
                return "Data Already Present";
            }
        }

        // CHECK WHETHER GROUP COMPANYNAME IS PRESENT
        var group_id;
        if (groupcompanyname != null) {
            //** QUERY to fetch groupid acc to group name from groups table **//
            const query1 = await pool.query('SELECT group_id FROM customer_onboarding.groups WHERE group_name=$1', [groupcompanyname]);
            // console.log("group_id", query1.rows);
            group_id = query1.rows[0].group_id;
        }
        else {
            group_id = null;
        }

        //** QUERY to insert customer details **//
        const result1 = await pool.query('INSERT INTO customer_onboarding.customer_details (sap_customer_id,company_name,primary_contact_name,primary_email,secondary_email,primary_contact_no,secondary_contact_no,site_address,gst_no,pan_no,gst_pan,group_id,customer_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)', [sapcustomerid, companyname, primaryname, primaryemail, secondaryemail, primarycontact, secondarycontact, siteaddress, gstno, panno, customerdoc, group_id, customerid]);
        // console.log("POST Customer Details result1", result1);

        //** QUERY TO INSERT name,email,role & customerid INTO LOGIN TABLE */
        const role = 'customer';
        const result2 = await pool.query('INSERT INTO customer_onboarding.login (username,email,role,customer_id) VALUES ($1, $2, $3, $4)', [primaryname,primaryemail,role,customerid]);
        // console.log("POST Customer in login result2", result2);


        return result2.command;
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }

}

//Edit Customer 
async function editCustomers(req, res) {

    formControlCheck(req.body);
    console.log("EDIT Customer", req.body);
    var customerdoc;  // storing file path

    try {
        // CHECK WHETHER ATTACHMENT IS PRESENT
        console.log("req.files:", req.files.length)
        if (req.files.length) {
            // console.log("req.files", req.files);
            customerdoc = req.files[0].path;
            console.log("attachment IF", customerdoc);
            var { sapcustomerid, companyname, primaryname, primaryemail, secondaryemail, primarycontact, secondarycontact, siteaddress, gstno, panno, groupcompanyname, customerid } = req.body;
        }
        else {
            // customerdoc = null;
            var { sapcustomerid, companyname, primaryname, primaryemail, secondaryemail, primarycontact, secondarycontact, siteaddress, gstno, panno, attachment, groupcompanyname, customerid } = req.body;
            customerdoc = attachment;
            console.log("attachment ELSE", customerdoc);
        
        }
        // console.log("attachment", customerdoc);

        console.log("customerid", customerid, groupcompanyname);

        // CHECK WHETHER GROUP COMPANYNAME IS PRESENT
        var group_id;
        if (groupcompanyname != null) {
            //** QUERY to fetch groupid acc to group name from groups table **//
            const query1 = await pool.query('SELECT group_id FROM customer_onboarding.groups WHERE group_name=$1', [groupcompanyname]);
            // console.log("group_id", query1.rows);
            group_id = query1.rows[0].group_id;
        }
        else {
            group_id = null;
        }

        // //** QUERY to update customer details **//
        const result = await pool.query('UPDATE customer_onboarding.customer_details SET sap_customer_id=$1,company_name=$2,primary_contact_name=$3,primary_email=$4,secondary_email=$5,primary_contact_no=$6,secondary_contact_no=$7,site_address=$8,gst_no=$9,pan_no=$10,gst_pan=$11,group_id=$12 WHERE customer_id=$13', [sapcustomerid, companyname, primaryname, primaryemail, secondaryemail, primarycontact, secondarycontact, siteaddress, gstno, panno, customerdoc, group_id, customerid]);
        console.log("EDIT Customer Details result", result.command);
        // return result.command;

        //** QUERY TO UPDATE name,email,role & customerid INTO LOGIN TABLE */
        const role = 'customer';
        const result2 = await pool.query('UPDATE customer_onboarding.login SET username=$1, email=$2, role=$3 WHERE customer_id=$4', [primaryname,primaryemail,role,customerid]);
        // console.log("EDIT Customer in login result2", result2);
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }

}

// delete Customer 
// async function deleteCustomers(req, res) {

//     try {
//         const { customerId } = req.body;
//         const result = await pool.query('DELETE FROM customer_onboarding.customer_details WHERE customer_id=$1', [customerId]);
//         return result.command;
//     }
//     catch (error) {
//         console.log("ERROR delete", error.message);
//         return "Unsuccessful";
//     }

// }

module.exports = {
    // validateCustomers,
    getCustomers,
    postaddCustomers,
    editCustomers,
    // deleteCustomers,
}