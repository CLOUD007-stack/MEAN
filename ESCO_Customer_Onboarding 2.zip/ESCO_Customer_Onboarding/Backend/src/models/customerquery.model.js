const { pool } = require('../config/database.postgres');

/**
 * CUSTOMER SECTION 
 */

// FETCHING QUERIES FOR PARTICULAR CUSTOMER
async function getcustomerQuery(req, res) {

    const customerid = req.query['customerid'];
    console.log("GET getcustomerQuery customerid", customerid);

    try {        
        const result = await pool.query('SELECT * FROM customer_onboarding.customer_query WHERE customer_id=$1', [customerid]);
        // console.log("GET getcustomerQuery result", result.rows);

        if (result.rowCount == 0) {
            console.log("rowCount", result.rowCount);
            return "No Data Available";
        }
        else {
            // GETTING servicename OF PARTICULAR SERVICES
            for(let s=0; s<result.rows.length; s++) {
                let serviceid = result.rows[s].service_id;
                console.log("serviceid", serviceid, customerid);

                // QUERY TO FETCH SERVICE NAME & URL LINK
                const queryServiceName = await pool.query(`SELECT service_name FROM customer_onboarding.services WHERE service_id=$1`, [serviceid]); 
                // console.log("queryServiceName", queryServiceName.rows);

                result.rows[s]['servicename'] = queryServiceName.rows[0].service_name;

            }

        }
        // console.log("FINAL result", result.rows);
        return result.rows;
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}


async function postcustomerQuery(req, res) {

    console.log("POST postcustomerQuery", req.body);
    try {
        // CHECK WHETHER ATTACHMENT IS PRESENT
        console.log("req.files:", req.files.length);
        if (req.files.length) {
            // console.log("req.files", req.files);
            var customerdoc = req.files[0].path;
        }
        else {
            var customerdoc = null;
        }
        console.log("attachment", customerdoc);

        const { customerid, serviceid, category, subcategory, description } = req.body;

        // // CHECK FOR ALREADY PRESENT DATA [BASIS -> category]
        // // ** QUERY TO FETCH Query Category TABLE DATA 
        // const queries = await pool.query(`SELECT * FROM customer_onboarding.query_category`);
        // console.log("post query", queries.rows);
        // for(let g=0; g<queries.rows.length; g++) {
        //     if(category == queries.rows[g].category) {
        //         console.log("Data Already Present") ;
        //         return "Data Already Present";
        //     }
        // }

        // FETCH CUSTOMERID BASED ON UID

        //
        
        let status = "Pending";
        const result = await pool.query('INSERT INTO customer_onboarding.customer_query (category,subcategory,description,attachment,service_id,customer_id,status) VALUES ($1,$2,$3,$4,$5,$6,$7)', [category,subcategory,description,customerdoc,serviceid,customerid,status]);
        console.log("POST postcustomerQuery result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR query", error.message);
        return "Unsuccessful";
    }
}

async function postQueryDescription(req, res) {

    console.log("POST postQueryDescription", req.body);
    try {
        const { description, cqid } = req.body;
        
        // ** QUERY TO APPEND DESCRIPTION OF CUSTOMER QUERY
        const result = await pool.query(`UPDATE customer_onboarding.customer_query SET description=description || '. ' || $1 WHERE cq_id = $2`, [description,cqid]);
        console.log("POST postQueryDescription result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR group", error.message);
        return "Unsuccessful";
    }
}


/**
 * ADMIN SECTION 
 */

// FETCHING QUERIES OF ALL THE CUSTOMERS (ADMIN SECTION)
async function getcustomerQueries(req, res) {

    const customerid = req.query['customerid'];
    console.log("GET getcustomerQuery customerid", customerid);

    try {        
        const result = await pool.query('SELECT * FROM customer_onboarding.customer_query');
        // console.log("GET getcustomerQueries result", result.rows);

        if (result.rowCount == 0) {
            console.log("rowCount", result.rowCount);
            return "No Data Available";
        }
        else {
            // GETTING servicename OF PARTICULAR SERVICES
            for(let s=0; s<result.rows.length; s++) {
                let serviceid = result.rows[s].service_id;
                let customerid = result.rows[s].customer_id;
                console.log("serviceid", serviceid, customerid);

                // QUERY TO FETCH SERVICE NAME & URL LINK
                const queryServiceName = await pool.query(`SELECT service_name FROM customer_onboarding.services WHERE service_id=$1`, [serviceid]); 
                console.log("queryServiceName", queryServiceName.rows);

                result.rows[s]['servicename'] = queryServiceName.rows[0].service_name;

                // QUERY TO FETCH CUSTOMER DETAILS USING CUSTOMERID
                const customerdetails = await pool.query(`SELECT * FROM customer_onboarding.customer_details WHERE customer_id=$1`, [customerid]); 
                console.log("customerdetails", customerdetails.rows);

                result.rows[s]['companyname'] = customerdetails.rows[0].company_name;
                result.rows[s]['contactname'] = customerdetails.rows[0].primary_contact_name;
                result.rows[s]['email'] = customerdetails.rows[0].primary_email;
                result.rows[s]['phone'] = customerdetails.rows[0].primary_contact_no;

            }

        }
        // console.log("FINAL result", result.rows);
        return result.rows;
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}

async function postQueryStatus(req, res) {

    console.log("POST postQueryStatus", req.body);
    try {
        const { status, cq_id, customer_id } = req.body;
        
        // ** QUERY TO APPEND DESCRIPTION OF CUSTOMER QUERY
        const result = await pool.query(`UPDATE customer_onboarding.customer_query SET status=$1 WHERE cq_id = $2 AND customer_id=$3`, [status,cq_id,customer_id]);
        console.log("POST postQueryStatus result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR query", error.message);
        return "Unsuccessful";
    }
}

module.exports = {
    postcustomerQuery,
    getcustomerQueries,
    getcustomerQuery,
    postQueryDescription,
    postQueryStatus
}