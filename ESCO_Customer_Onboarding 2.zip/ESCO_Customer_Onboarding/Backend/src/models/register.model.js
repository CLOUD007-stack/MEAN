const { query } = require('express');
const { pool } = require('../config/database.postgres');
// const Joi = require('joi')
const bcrypt = require("bcrypt");


async function registerModel(req, res) {

    const { user_name, email, role, password } = req.body;
    
    console.log("Register", req.body);
    
    try {

        // generate salt to hash password
        const salt = await bcrypt.genSalt(10);

        // now we set user password to hashed password
        const hash = await bcrypt.hash(password, salt);
        console.log("register", hash);

        const result = await pool.query('INSERT INTO customer_onboarding.login (username, email, role, password) VALUES ($1, $2, $3, $4)', [ user_name, email, role, hash]);
        console.log("Register", result.command);
        
        return result.command;
    }
    catch (error) {
        console.log("ERROR Register", error.message);
        return "Unsuccessful";
    }
}


module.exports = {
    // validateRegister,
    registerModel

}