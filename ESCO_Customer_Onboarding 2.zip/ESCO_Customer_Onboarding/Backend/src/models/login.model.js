// const { query } = require('express');
const { pool } = require('../config/database.postgres');
const bcrypt = require("bcrypt");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const mail = require('../functions/func');

// const verifyJWToken = require('../middleware/auth');
// async function login(req, res) {
//     try {
//         const { email, password } = req.body;
//         const users = await pool.query('SELECT * FROM customer_onboarding.login WHERE email = $1', [email]);
//         //console.log("Login Result---->", users);
//         if (users.rows.length === 0) return res.status(401).json({ error: "Email is incorrect" });
//         //Compare and Password Check
//         const validPassword = await bcrypt.compare(password, users.rows[0].password);
//         if (!validPassword) return res.status(401).json({ error: "Incorrect Password" });
//         return res.status(200).json("Success Login");
//     } catch {
//         res.status(401).json({ error: error.message });
//     }
// }

async function login(req, res) {
    try {
        const { email, password } = req.body;
        console.log("Login req---->", req.body);
        const users = await pool.query('SELECT * FROM customer_onboarding.login WHERE email = $1', [email]);
        console.log("Login Result---->", users.rows);
        // CHECK FOR INVALID EMAIL
        if (users.rows.length == 0) {
            console.log("Email is incorrect");
            return "INVALID";
            // return res.status(401);
        }
        //// CHECK FOR INVALID PASSWORD
        const validPassword = await bcrypt.compare(password, users.rows[0].password);
        console.log("Login validPassword---->", validPassword);
        if (!validPassword) {
            console.log("!validPassword", validPassword);
            return "INVALID";
        }
        // VALID EMAIL & PASSWORD
        const userData = {
            username: users.rows[0].username,
            email: users.rows[0].email,
            role: users.rows[0].role,
            customerid: users.rows[0].customer_id
        }
        return userData;
    }
    catch {
        res.status(401).json({ error: error.message });
    }
}

async function postEmail(req, res) {
    try {
        const { email, customerid } = req.body;
        console.log("postEmail req---->", req.body);
        // QUERY TO VALIDATE EMAIL,CUSTOMERID FROM LOGIN TABLE
        const credentials = await pool.query('SELECT email, customer_id FROM customer_onboarding.login');
        console.log("postEmail Result---->", credentials.rows);
        for (let i = 0; i < credentials.rows.length; i++) {
            console.log("credentials.rows[i].email", credentials.rows[i].email);
            if (email == credentials.rows[i].email && customerid == credentials.rows[i].customer_id) {
                console.log("TRUE");
                return true;
            }
        }
        return false;
    }
    catch {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }
}

// GENERIC SEND MAIL FUNCTION
async function sendMail(emailOptions) {
    // NODE MAILER - TO SEND LINK TO EMAIL
    // Create transporter object 
    let transporter = nodemailer.createTransport({
        tls: {
            rejectUnauthorized: false
        },
        host: "mail.tpc.co.in", // SMTP server
        port: 25,
        secure: false, // true for 465, false for other ports
    });

    transporter.verify(function (error, success) {
        if (error) {
            console.log('ERROR: ', error);
        } else {
            console.log('Server is ready to take our messages');
        }
    });

    // console.log("transporter", transporter);
    let mailOptions = emailOptions;
    console.log("emailOptions", emailOptions);
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log("FAILED MAIL", error);
            transporter.close();
            return false;
        }
        else {
            console.log('MAIL SENT');
            // transporter.close();
            return true;
        }

    });

}

// SENDING RESET LINK TO USER'S MAIL
async function postSendLink(req, res) {
    try {
        const { email } = req.body;
        console.log("postSendLink req---->", req.body, email);
        // QUERY TO VALIDATE EMAIL FROM LOGIN TABLE
        const emails = await pool.query('SELECT email FROM customer_onboarding.login');
        console.log("postSendLink Result---->", emails.rows);
        for (let i = 0; i < emails.rows.length; i++) {
            // console.log("FOR", email, "-->", emails.rows[i].email);

            //1. MAIL VALIDITY CHECK
            if (email == emails.rows[i].email) { // if email is valid
                console.log("TRUE");
                let customeridrows = await pool.query(`SELECT customer_id FROM customer_onboarding.login WHERE email=$1`, [email]);
                let customerid = customeridrows.rows[0].customer_id;

                // 2. TOKEN CHECK & GENERATION
                const tokenrows = await pool.query(`SELECT token FROM customer_onboarding.reset_password WHERE customer_id=$1`, [customerid]);
                // console.log("tokenrows",tokenrows);
                var token;
                console.log("token", token, customerid);
                if (tokenrows.rowCount == 0) { // if token not present
                    token = crypto.randomBytes(32).toString("hex"); // creating token
                    // console.log("tokenIN", token);
                    // QUERY TO INSERT TOKEN CORRESPONDING TO THAT ID IN RESET_PASSWORD TABLE
                    const result = await pool.query(`INSERT INTO customer_onboarding.reset_password (token,customer_id) VALUES ($1,$2)`, [token, customerid]);
                    // console.log("result", result);
                }
                else { // if token present
                    token = tokenrows.rows[0]['token'];
                }
                console.log("tokenOUT", token);
                let link = 'https://analytics-dev.tatapower.com/escoCustomerOnboarding/reset-password/' + token;
                console.log("link", link);

                // SEND  MAIL
                let emailOptions = {
                    from: 'esco@tatapower.com', // sender address
                    to: email, // list of receivers
                    subject: "Password Reset Link", // Subject line
                    text: 'You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n' +
                        'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
                        link + '\n\n' +
                        'If you did not request this, please ignore this email and your password will remain unchanged.\n'
                };


                if (mail.sendMail(emailOptions)) {
                    return 'A reset link has been sent to your email. Kindly check.';
                }
                else {
                    return 'Unable to send mail.';
                }
            }
        }
        return false;  // if email not valid
    }
    catch {
        console.log("ERROR post", error);
        return "Unsuccessful";
    }
}


async function validateResetLink(req, res) {
    try {
        const { resettoken } = req.body;
        console.log("resettoken",resettoken);

        const tokenrows = await pool.query(`SELECT * FROM customer_onboarding.reset_password WHERE token=$1`, [resettoken]);
        console.log("tokenrows", tokenrows);
        
        if (tokenrows.rowCount == 0) { // if token not present in table
            return 'Not Verified';
        }
        else { // if token present, matching the token for validity
            let token = tokenrows.rows[0]['token'];
            let customer_id = tokenrows.rows[0]['customer_id'];

            // FETCH EMAIL FROM LOGIN TABLE TO SEND TO FRONTEND
            let emailrows = await pool.query(`SELECT email FROM customer_onboarding.login WHERE customer_id=$1`, [customer_id]);
            let email = emailrows.rows[0]['email'];
            console.log("email", email);

            if (resettoken == token) {
                return 'Verified+' + email;
            }
        }
        
    }
    catch {
        console.log("ERROR post", error);
        return "Unsuccessful";
    }
}


async function resetPassword(req, res) {
    try {
        console.log("resetPassword req.body",req.body);  //{ email: '', password: 'fsdgdf', confirm: 'dfszd' }
        const {email, password} = req.body;
        console.log("password",password);

        // PASSWORD HASH
        // generate salt to hash password
        const salt = await bcrypt.genSalt(10);

        // now we set user password to hashed password
        const hashpassword = await bcrypt.hash(password, salt);
        console.log("register", hashpassword);

        // UPDATE PASSWORD IN LOGIN TABLE
        const result = await pool.query(`UPDATE customer_onboarding.login SET password=$1 WHERE email=$2`, [hashpassword,email]);
        console.log("result.command",result.command);
        return result.command;

        
    }
    catch {
        console.log("ERROR post", error);
        return "Unsuccessful";
    }
}

module.exports = {
    login,
    postEmail,
    postSendLink,
    validateResetLink,
    resetPassword
}