const mail = require('../functions/func');
// const { query } = require('express');
const { pool } = require('../config/database.postgres');
const bcrypt = require("bcryptjs");


async function getUsers(req, res) {
    console.log("GET USERS");
    const customerid = req.query['customerid'];  // From frontend

    try {
        //** QUERY to get user details from user table acc to customer **//
        const query1 = await pool.query('SELECT * FROM customer_onboarding.user WHERE customer_id=$1', [customerid]);

        for (let u = 0; u < query1.rowCount; u++) {
            const user_id = query1.rows[u].uid;
            // console.log("user_id", user_id)

            //** QUERY to get service & partner for particular user **//
            const query2 = await pool.query(`SELECT service_name || '-' || partner AS servicepartner FROM customer_onboarding.services WHERE service_id IN (SELECT service_id FROM customer_onboarding.user_service WHERE uid=$1)`, [user_id]);
            // console.log("query2.rows", query2.rows);
            const servicecount = query2.rows.length;

            // Getting service-partner from service_id
            let serviceArr = [];
            for (let s = 0; s < servicecount; s++) {
                serviceArr.push(query2.rows[s]);
            }

            query1.rows[u]['servicescount'] = servicecount;
            query1.rows[u]['servicepartner'] = serviceArr;

        }

        // console.log("query1.rows", query1.rows);

        return query1.rows;
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}

async function postUser(req, res) {

    console.log("POST USERS", req.body);
    const { personname, email, contact, gender, password, designation, department, location, servicepartner, customerid } = req.body;

    console.log("password", password);

    try {
        const serviceidArr = [];  // To store service ids

        for (let i = 0; i < servicepartner.length; i++) {
            const servicename = servicepartner[i].servicepartner.split('-')[0];
            const partner = servicepartner[i].servicepartner.split('-')[1];
            // console.log("sp", servicename,partner);

            // Getting service_id from services table acc to service & partner
            const query_serviceid = await pool.query('SELECT service_id FROM customer_onboarding.services WHERE service_name=$1 and partner=$2', [servicename, partner]);
            const service_id = query_serviceid.rows[0].service_id;
            // console.log("service_id", service_id);

            // Pushing service ids in Array
            serviceidArr.push(service_id);

        }
        // console.log("serviceidArr", serviceidArr);

        // DATA ALREADY PRESENT  - (BASIS -> email || contact)

        // Fetching conatct & email_id from user table to check if already present
        const query_emailcontact = await pool.query('SELECT email_id,contact FROM customer_onboarding.user');
        // console.log("query_email", query_email);
        for (let row = 0; row < query_emailcontact.rows.length; row++) {
            if(email == query_emailcontact.rows[row].email_id || contact == query_emailcontact.rows[row].contact){
                console.log("Data Already Present") ;
                return "Data Already Present";
            }
        }


        // PASSWORD ENCRYPTION
        const hashedPassword = await bcrypt.hash(password, 8);
        // console.log("hashedPassword", hashedPassword);


        //** QUERY to insert user data and extracting uid (auto) **//
        const query1 = await pool.query('INSERT INTO customer_onboarding.user (user_name,gender,email_id,password,contact,location,designation,department,customer_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING uid', [ personname, gender, email, hashedPassword, contact, location, designation, department, customerid]);
        // console.log("POST USER query1", query1.rows[0].uid, query1.command);
        const uid = query1.rows[0].uid;

        // // QUERY TO INSERT USER IN LOGIN TABLE
        // const role = 'user';
        // const query2 = await pool.query('INSERT INTO customer_onboarding.login (username,email,password,role,customer_id) VALUES ($1, $2, $3, $4, $5)', [ personname, email, hashedPassword, role, uid]);
        // // console.log("POST USER query2", query2.rows[0].uid, query2.command);



        for (let s = 0; s < serviceidArr.length; s++) {
            console.log(serviceidArr[s]);

            //** QUERY to insert in the user_service table(child table) acc to uid (user) **//
            const query2 = await pool.query(`INSERT INTO customer_onboarding.user_service (uid, service_id) VALUES ($1, $2)`, [uid, serviceidArr[s]]);
            // console.log("POST USER query2", query2.rows);
        }

        return query1.command;
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }
}

async function editUser(req, res) {

    console.log("EDIT USERS", req.body);
    const { personname, email, contact, gender, password, designation, department, location, servicepartner, customerid, uid } = req.body;

    // console.log("EDIT USERS", servicepartner.length);

    try {
        const serviceidArr = [];  // To store service ids

        for (let i = 0; i < servicepartner.length; i++) {
            const servicename = servicepartner[i].servicepartner.split('-')[0];
            const partner = servicepartner[i].servicepartner.split('-')[1];
            // console.log("sp", servicename,partner);

            // Getting service_id from services table acc to service & partner
            const query_serviceid = await pool.query('SELECT service_id FROM customer_onboarding.services WHERE service_name=$1 and partner=$2', [servicename, partner]);
            const service_id = query_serviceid.rows[0].service_id;
            // console.log("service_id", service_id);

            // Pushing service ids in Array
            serviceidArr.push(service_id);
        }
        // console.log("serviceidArr", serviceidArr);


        // //** QUERY to insert user data and extracting uid (auto) **//
        const query1 = await pool.query('UPDATE customer_onboarding.user SET user_name=$1, gender=$2, email_id=$3, password=$4, contact=$5, location=$6, designation=$7, department=$8, customer_id=$9 WHERE uid=$10', [ personname, gender, email, password, contact, location, designation, department, customerid, uid]);
        console.log("EDIT USER query1", query1.command);
        // const uid = query1.rows[0].uid;


        // Delete previous data from user_service table
        const query2 = await pool.query('DELETE FROM customer_onboarding.user_service WHERE uid=$1', [uid]);
        // console.log("EDIT USER query2", query2.command);


        for (let s = 0; s < serviceidArr.length; s++) {
            console.log(serviceidArr[s]);

            //** QUERY to insert in the user_service table(child table) acc to uid (user) **//
            const query3 = await pool.query(`INSERT INTO customer_onboarding.user_service (uid, service_id) VALUES ($1, $2)`, [uid, serviceidArr[s]]);
            // console.log("POST USER query3", query3.rows);
        }

        return query1.command;
    }
    catch (error) {
        console.log("ERROR edit", error.message);
        return "Unsuccessful";
    }
}

async function sendMailToCustomer(req, res) {

    console.log("POST USERS", req.body);
    const { customerid } = req.body;
    console.log("customerid", customerid);

    try {  
        const customer = await pool.query(`SELECT primary_contact_name, primary_email FROM customer_onboarding.customer_details WHERE customer_id=$1`, [customerid]);
        console.log("customer.rows",customer.rows);
        
        let emailOptions = {
            from: 'esco@tatapower.com', // sender address
            to: customer.rows[0]['primary_email'], // list of receivers
            subject: "Registration Done", // Subject line
            text: 'Hi ' + customer.rows[0]['primary_contact_name'] + ',\n\n' +
                  'Your registration is done!' + '\n' +
                  'Your Customer ID: ' + customerid + '\n\n' +
                  'Thanks'
        };

        if (mail.sendMail(emailOptions)) {
            return 'Registration Mail Sent to Customer';
        }
        else {
            return 'Unable to send mail';
        }
    }
    catch (error) {
        console.log("ERROR post", error.message);
        return "Unsuccessful";
    }
}


module.exports = {
    getUsers,
    postUser,
    editUser,
    sendMailToCustomer
}