const { pool } = require('../config/database.postgres');

async function postGroup(req, res) {

    console.log("POST GROUP", req.body);
    try {
        const { groupname } = req.body;

        // CHECK FOR ALREADY PRESENT DATA [BASIS -> groupname]
        // ** QUERY TO FETCH GROUPS TABLE DATA 
        const groups = await pool.query(`SELECT * FROM customer_onboarding.groups`);
        console.log("post groups", groups.rows);
        for(let g=0; g<groups.rows.length; g++) {
            if(groupname == groups.rows[g].group_name) {
                console.log("Data Already Present") ;
                return "Data Already Present";
            }
        }
        
        const result = await pool.query('INSERT INTO customer_onboarding.groups (group_name) VALUES ($1)', [groupname]);
        // console.log("POST GROUP result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR group", error.message);
        return "Unsuccessful";
    }
}


module.exports = {
    postGroup
}