const { pool } = require('../config/database.postgres');

async function editDetails(req, res) {

    console.log("EDIT", req.body);

    try {
        const { query } = req.body;
        console.log("EDIT query", query);
        const result = await pool.query(query);
        // console.log("EDIT SERVICES result", result);
        return result.command;
    }
    catch (error) {
        console.log("ERROR edit", error.message);
        return "Unsuccessful";
    }

}


module.exports = {
    editDetails
}