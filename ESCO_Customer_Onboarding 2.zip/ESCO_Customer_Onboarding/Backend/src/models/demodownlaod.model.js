const { pool } = require('../config/database.postgres');

async function postDemoDownlaod(req, res) {

    console.log("POST DemoDownlaod", req.body);
    try {
        const { name, company, email, phone, message, requestdemo, download } = req.body;

        // CHECK FOR ALREADY PRESENT DATA [BASIS -> email]
        // ** QUERY TO FETCH NEW CUSTOMER QUERY TABLE DATA 
        const queries = await pool.query(`SELECT * FROM customer_onboarding.new_customer_query`);
        console.log("post queries", queries.rows);
        for(let q=0; q<queries.rows.length; q++) {
            if((email == queries.rows[q].email && requestdemo == queries.rows[q].request_demo) || (email == queries.rows[q].email && download == queries.rows[q].download)) {
                console.log("Data Already Present") ;
                return "Data Already Present";
            }
        }
        
        const result = await pool.query('INSERT INTO customer_onboarding.new_customer_query (name,companyname,email,contact,message,request_demo,download) VALUES ($1,$2,$3,$4,$5,$6,$7)', [name, company, email, phone, message, requestdemo, download]);
        console.log("POST DemoDownlaod result", result.command);
        return result.command;
    }
    catch (error) {
        console.log("ERROR DemoDownlaod", error.message);
        return "Unsuccessful";
    }
}


module.exports = {
    postDemoDownlaod
}