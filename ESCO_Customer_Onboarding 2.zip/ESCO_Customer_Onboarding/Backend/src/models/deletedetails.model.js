const { pool } = require('../config/database.postgres');


async function deleteDetails(req, res) {

    console.log("DELETE SERVICES", req.body);

    try {
        const { query } = req.body;
        console.log("DELETE query", query);
        const result = await pool.query(query);
        console.log("DELETE SERVICES result", result.command);
        return result.command;
    }
    catch (error) {
        console.log("ERROR delete", error.message);
        return "Unsuccessful";
    }    

}


module.exports = {
    deleteDetails
}