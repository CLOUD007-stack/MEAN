const { pool } = require('../config/database.postgres');


async function getDetails(req, res) {
    console.log("GET REQ QUERY",req.query['query']);
    const query = req.query['query'];

    try {
        const result = await pool.query(query);
        console.log("GET details", result.rows);
        if (result.rowCount == 0) {
            console.log(result.rowCount);
            return "No Data Available";
        }
        else return result.rows;
    }
    catch (error) {
        console.log("ERROR get", error.message);
        return "Unsuccessful";
    }
}



module.exports = {
    getDetails
}