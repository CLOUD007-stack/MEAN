const jwt = require('jsonwebtoken');
const path = require('path');


exports.renderBackendHome = (req, res) => {
    res.send("ESCO Customer Onboarding Backend Server")
}


/**
 * Register Page
 */

const demodownlaodModel = require('../models/demodownlaod.model');

exports.post_demodownload = async (req, res) => {

    // console.log("CONTROLLER POST Customer", req.body);

    const demodownlaodDetails = await demodownlaodModel.postDemoDownlaod(req, res);

    if (demodownlaodDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", demodownlaodDetails);
        res.status(200).json({ success: false, msg: demodownlaodDetails });
    }
    else if (demodownlaodDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: demodownlaodDetails });
    }
}


/**
 * Register Page
 */

const registerModel = require('../models/register.model');

exports.post_register = async (req, res) => {

    // console.log("CONTROLLER POST Customer", req.body);

    // const { error } = await registerModel.validateRegister(req);

    // if (error) return res.status(200).send({ success: false, msg: error.details[0].message });

    const registerUserDetails = await registerModel.registerModel(req, res);

    if (registerUserDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: registerUserDetails });
    }
}

/**
 * Login Page
 */

const loginModel = require('../models/login.model');

exports.post_login = async (req, res) => {

    // console.log("CONTROLLER LOGIN req", req.body);
    // Have to do -> Validating for client input service

    const loginDetails = await loginModel.login(req, res);
    console.log("CONTROLLER LOGIN status", loginDetails);

    // CHECK FOR INVALID USER
    if (loginDetails == "INVALID") {
        console.log("CONTROLLER Invalid user");
        res.status(200).json({ success: false, msg: "Invalid email or password." });

    }
    else {  // VALID USER
        console.log("CONTROLLER Valid user");
        // TOEKN GENERATION FOR API AUTHENTICATION
        // JWT DATA
        let useremail = loginDetails.email;
        console.log("CONTROLLER userdata", useremail);

        // JWT SECRET KEY 
        let jwtSecretKey = process.env.JWT_SECRET_KEY;

        // TOKEN EXPIRATION TIME
        let jwtExpiresIn = process.env.JWT_EXPIRES_IN;

        // TOKEN GENERATION
        const token = jwt.sign({ useremail: useremail }, jwtSecretKey, { expiresIn: jwtExpiresIn });
        console.log("CONTROLLER TOKEN", token);

        res.status(200).header('x-auth-token', token).json({ success: true, msg: "Login Successful", data: loginDetails });
    }
}

// exports.post_login = async (req, res) => {

//     console.log("CONTROLLER LOGIN req", req.body);
//     // Have to do -> Validating for client input service

//     const loginDetails = await loginModel.login(req, res);
//     console.log("CONTROLLER LOGIN", loginDetails);

//     if (loginDetails.status == 500) {
//         // Sending token in response header
//         res.status(404).json({ success: false, msg: loginDetails });

//     }
//     else {

//         // API Authentication JWToken
//         let jwtSecretKey = process.env.JWT_SECRET_KEY;

//         // Token Expiration
//         let jwtExpiresIn = process.env.JWT_EXPIRES_IN;

//         const token = jwt.sign(loginDetails, jwtSecretKey);

//         console.log("TOKEN", token);
//         res.status(200).header('x-auth-token', token).json({ success: true, msg: loginDetails });
//     }
// }

exports.post_email = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const loginDetails = await loginModel.postEmail(req, res);

    if (loginDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: loginDetails });
        // res.status(200).json({ serviceDetails: serviceDetails });
    }
}


exports.post_sendlink = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const loginDetails = await loginModel.postSendLink(req, res);

    if (loginDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: loginDetails });
        // res.status(200).json({ serviceDetails: serviceDetails });
    }
}

exports.validate_resetlink = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const loginDetails = await loginModel.validateResetLink(req, res);

    if (loginDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: loginDetails });
    }
}

exports.reset_password = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const loginDetails = await loginModel.resetPassword(req, res);

    if (loginDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: loginDetails });
    }
}




/**
 * Services Page
 */

const servicesModel = require('../models/services.model');

// exports.get_services = async (req, res) => {

//     const serviceDetails = await servicesModel.getServices(req, res);
//     // console.log("CONTROLLER GET SERVICES res", serviceDetails);

//     if (serviceDetails === 'No Data Available') {
//         console.log("No Data in services");
//         res.status(200).json({ success: false, msg: "No Data Available" });
//     }
//     else if (serviceDetails === 'Unsuccessful') {
//         res.status(200).json({ success: false, msg: "Something wrong happened" });
//     }
//     else {
//         res.status(200).json({ success: true, msg: serviceDetails });
//         // res.status(200).json({ serviceDetails: serviceDetails });
//     }
// }

exports.post_services = async (req, res) => {

    // console.log("CONTROLLER POST SERVICES", req.body);
    // Validating for client input service
    // const { error } = await servicesModel.validateService(req);
    // if (error) return res.status(200).send({ success: false, msg: error.details[0].message });

    const serviceDetails = await servicesModel.postServices(req, res);

    if (serviceDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", serviceDetails);
        res.status(200).json({ success: false, msg: serviceDetails });
    }
    else if (serviceDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: serviceDetails });
    }
}

// exports.edit_services = async (req, res) => {
//     console.log("EDIT SERVICE CONTROLLER",req);
//     const serviceDetails = await servicesModel.editServices(req, res);

//     if (serviceDetails === 'Unsuccessful') {
//         res.status(200).json({ success: false, msg: "Something wrong happened" });
//     }
//     else res.status(200).json({ success: true, msg: serviceDetails });
// }

// exports.delete_services = async (req, res) => {
//     const serviceDetails = await servicesModel.deleteServices(req, res);

//     if (serviceDetails === 'Unsuccessful') {
//         res.status(200).json({ success: false, msg: "Something wrong happened" });
//     }
//     else res.status(200).json({ success: true, msg: serviceDetails });
// }


/**
 * Group Page
 */

const groupModel = require('../models/group.model');

exports.post_group = async (req, res) => {

    console.log("CONTROLLER POST GROUP", req.body);

    const groupDetails = await groupModel.postGroup(req, res);

    if (groupDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", groupDetails);
        res.status(200).json({ success: false, msg: groupDetails });
    }
    if (groupDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: groupDetails });
    }
}


/**
 * Query Category Page
 */

const queryCategoryModel = require('../models/querycategory.model');

exports.post_query_category = async (req, res) => {

    console.log("CONTROLLER POST Query Category", req.body);

    const queryCategoryDetails = await queryCategoryModel.postQueryCategory(req, res);

    if (queryCategoryDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", queryCategoryDetails);
        res.status(200).json({ success: false, msg: queryCategoryDetails });
    }
    if (queryCategoryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: queryCategoryDetails });
    }
}

exports.post_query_subcategory = async (req, res) => {

    console.log("CONTROLLER POST Query Category", req.body);

    const queryCategoryDetails = await queryCategoryModel.postQuerySubCategory(req, res);

    if (queryCategoryDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", queryCategoryDetails);
        res.status(200).json({ success: false, msg: queryCategoryDetails });
    }
    if (queryCategoryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: queryCategoryDetails });
    }
}


/**
 * Add Customer Page
 */

const addcustomersModel = require('../models/addCustomers.model');

exports.get_addCustomers = async (req, res) => {

    const customer_details = await addcustomersModel.getCustomers(req, res);

    if (customer_details === 'No Data Available') {
        console.log("No Data in customer_details");
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (customer_details === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customer_details });

    }
}

exports.post_addCustomers = async (req, res) => {

    // console.log("CONTROLLER POST Customer", req.body);

    // const { error } = await addcustomersModel.validateCustomers(req);
    // if (error) return res.status(200).send({ success: false, msg: error.details[0].message });

    // await uploadFile(req, res);
    // await uploadFile(req, res);
    // console.log("CONTROLLER post_addCustomers", req);

    const customerDetails = await addcustomersModel.postaddCustomers(req, res);

    if (customerDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", customerDetails);
        res.status(200).json({ success: false, msg: customerDetails });
    }
    else if (customerDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerDetails });
    }
}

exports.edit_customers = async (req, res) => {

    console.log("CONTROLLER edit_customers", req.body);

    const customerDetails = await addcustomersModel.editCustomers(req, res);

    if (customerDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerDetails });
    }
}

// exports.delete_addCustomers = async (req, res) => {
//     const customerDetails = await addcustomersModel.deleteCustomers(req, res);

//     if (customerDetails === 'Unsuccessful') {
//         res.status(200).json({ success: false, msg: "Something wrong happened" });
//     }
//     else res.status(200).json({ success: true, msg: customerDetails });
// }


/**
 * Add Customer Service Page
 */

const custservicesModel = require('../models/customerservices.model');

exports.get_cust_services = async (req, res) => {

    const custserviceDetails = await custservicesModel.getCustomerServices(req, res);
    // console.log("CONTROLLER GET SERVICES res", custserviceDetails);

    if (custserviceDetails === 'No Data Available') {
        console.log("No Data in services");
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (custserviceDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: custserviceDetails });
        // res.status(200).json({ custserviceDetails: custserviceDetails });
    }
}

exports.post_custservice = async (req, res) => {

    console.log("CONTROLLER POST CUST SERVICES", req.body);
    // Validating for client input service
    // const { error } = await servicesModel.validateService(req);
    // if (error) return res.status(200).send({ success: false, msg: error.details[0].message });

    const custserviceDetails = await custservicesModel.postcustServices(req, res);
    // res.status(200).json({ success: true, msg: custserviceDetails });

    if (custserviceDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", custserviceDetails);
        res.status(200).json({ success: false, msg: custserviceDetails });
    }
    else if (custserviceDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: custserviceDetails });
    }
}

exports.edit_custservice = async (req, res) => {

    console.log("CONTROLLER EDIT CUST SERVICES", req.body);

    const custserviceDetails = await custservicesModel.editcustServices(req, res);
    // res.status(200).json({ success: true, msg: custserviceDetails });

    if (custserviceDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: custserviceDetails });
    }
}


/**
 * Add User Page
 */
const usersModel = require('../models/adduser.model');

exports.get_user = async (req, res) => {

    const userDetails = await usersModel.getUsers(req, res);
    // console.log("CONTROLLER GET USERS res", userDetails);

    if (userDetails === 'No Data Available') {
        console.log("No Data in services");
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (userDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: userDetails });
        // res.status(200).json({ userDetails: userDetails });
    }
}

exports.post_user = async (req, res) => {

    // console.log("CONTROLLER POST USER", req.body);

    const userDetails = await usersModel.postUser(req, res);
    // res.status(200).json({ success: true, msg: userDetails });

    if (userDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", userDetails);
        res.status(200).json({ success: false, msg: userDetails });
    }
    else if (userDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: userDetails });
    }
}

exports.edit_user = async (req, res) => {

    // console.log("CONTROLLER EDIT USER", req.body);

    const userDetails = await usersModel.editUser(req, res);
    // res.status(200).json({ success: true, msg: userDetails });

    if (userDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", userDetails);
        res.status(200).json({ success: false, msg: userDetails });
    }
    else if (userDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: userDetails });
    }
}

exports.send_mail = async (req, res) => {

    // console.log("CONTROLLER POST USER", req.body);

    const userDetails = await usersModel.sendMailToCustomer(req, res);
    // res.status(200).json({ success: true, msg: userDetails });

    if (userDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: userDetails });
    }
}



/**
 * Download File
 */

exports.get_attachment = async (req, res) => {

    // console.log("CONTROLLER DOWNLOAD req", req.query);
    const attachment = req.query['attachment'];
    // console.log("attachment path", attachment);
    const filePathArr = attachment.split('/');

    const fileName = filePathArr[filePathArr.length - 1];
    // console.log("fileName", fileName);
    const directoryPath = attachment;
    // console.log("directoryPath", directoryPath);

    res.download(directoryPath, fileName, (err) => {
        if (err) {
            res.status(500).json({message:"Could not download the file."});
        }
    });

}


/**
 * GET
 */
const getModel = require('../models/getdetails.model');

exports.get_details = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const getDetails = await getModel.getDetails(req, res);


    if (getDetails === 'No Data Available') {
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (getDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: getDetails });
        // res.status(200).json({ serviceDetails: serviceDetails });
    }
}

/**
 * DELETE
 */

const deleteModel = require('../models/deletedetails.model');

exports.delete_details = async (req, res) => {
    // console.log("CONTROLLER DELETE req", req);

    const deleteDetails = await deleteModel.deleteDetails(req, res);

    if (deleteDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else res.status(200).json({ success: true, msg: deleteDetails });

}

/**
 * EDIT
 */

const editModel = require('../models/editdetails.model');

exports.edit_details = async (req, res) => {
    console.log("CONTROLLER EDIT req", req);

    const editDetails = await editModel.editDetails(req, res);

    if (editDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else res.status(200).json({ success: true, msg: editDetails });

}



/**
 * CUSTOMER SECTION
 */
const customerDetailsModel = require('../models/customerdetails.model');

exports.get_customer_details = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const getCustomerDetails = await customerDetailsModel.getCustomerDetails(req, res);


    if (getCustomerDetails === 'No Data Available') {
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (getCustomerDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: getCustomerDetails });
    }
}

/**
 * Customer Query
 */ 

const customerQueryModel = require('../models/customerquery.model');

exports.get_customer_query = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const customerQueryDetails = await customerQueryModel.getcustomerQuery(req, res);


    if (customerQueryDetails === 'No Data Available') {
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (customerQueryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerQueryDetails });
    }
}

exports.get_customer_queries = async (req, res) => {

    // console.log("CONTROLLER GET req", req);
    const customerQueryDetails = await customerQueryModel.getcustomerQueries(req, res);


    if (customerQueryDetails === 'No Data Available') {
        res.status(200).json({ success: false, msg: "No Data Available" });
    }
    else if (customerQueryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerQueryDetails });
    }
}

exports.post_customer_query = async (req, res) => {

    // console.log("CONTROLLER POST Customer", req.body);

    // await uploadFile(req, res);
    // await uploadFile(req, res);
    // console.log("CONTROLLER post_addCustomers", req);

    const customerQueryDetails = await customerQueryModel.postcustomerQuery(req, res);

    if (customerQueryDetails === 'Data Already Present') {
        console.log("CONTROLLER Data Already Present", customerQueryDetails);
        res.status(200).json({ success: false, msg: customerQueryDetails });
    }
    else if (customerQueryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerQueryDetails });
    }
}

exports.post_query_description = async (req, res) => {

    // console.log("CONTROLLER POST SERVICES", req.body);
    // Validating for client input service
    // const { error } = await servicesModel.validateService(req);
    // if (error) return res.status(200).send({ success: false, msg: error.details[0].message });

    const customerQueryDetails = await customerQueryModel.postQueryDescription(req, res);

    if (customerQueryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerQueryDetails });
    }
}

exports.post_query_status = async (req, res) => {

    // console.log("CONTROLLER POST SERVICES", req.body);
    // Validating for client input service
    // const { error } = await servicesModel.validateService(req);
    // if (error) return res.status(200).send({ success: false, msg: error.details[0].message });

    const customerQueryDetails = await customerQueryModel.postQueryStatus(req, res);

    if (customerQueryDetails === 'Unsuccessful') {
        res.status(200).json({ success: false, msg: "Something wrong happened" });
    }
    else {
        res.status(200).json({ success: true, msg: customerQueryDetails });
    }
}