const jwt = require('jsonwebtoken');
require('dotenv').config();

function verifyJWToken(req,res,next) {

    const token = req.header('x-auth-token');
    console.log("AUTH TOKEN", token);
    
    if(!token)  return res.status(401).send('Access Denied! Access token required!');

    try{
        // verify() -> if the token is not valid, it’ll throw an exception
        const decodedPayload = jwt.verify(token, process.env.JWT_SECRET_KEY);
        req.user = decodedPayload;
        next();
    }
    catch(exception){
        res.status(400).send('Invalid token!');
    }

}

module.exports = verifyJWToken;