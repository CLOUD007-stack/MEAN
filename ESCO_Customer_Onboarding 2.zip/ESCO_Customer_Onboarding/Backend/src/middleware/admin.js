// Middleware authorization
// TO check whether the user is admin or not but the token

function adminAuth(req,res,next) {

    if(!req.user.isAdmin) return res.status(403).send('Access Denied');
    next();

}

module.exports = adminAuth;