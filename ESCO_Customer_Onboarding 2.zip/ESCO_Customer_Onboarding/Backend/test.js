const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient()
const nodemailer = require("nodemailer");

// async function main() {
//   // ... you will write your Prisma Client queries here
//   const result = await prisma.groups.findMany();
//   console.log("PRISMA result", result);
// }

// main()
//   .then(async () => {
//     await prisma.$disconnect()
//   })
//   .catch(async (e) => {
//     console.error(e)
//     await prisma.$disconnect()
//     process.exit(1)
//   })

//TEST
async function postSendLink() {

  let testAccount = await nodemailer.createTestAccount();
  console.log("testAccount", testAccount);

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
      pool: true,
      host: "outlook.office365.com",
      port: 587,
      secure: true, // true for 465, false for other ports
      auth: {
          user: process.env.EMAIL, // generated ethereal user
          pass: process.env.PASSWORD, // generated ethereal password
      },
  });

  // console.log("transporter", transporter);

  // send mail with defined transport object
  let info = await transporter.sendMail({
      from: 'ayushi.gupta@tatapower.com', // sender address
      to: "arpit.s@tatapower.com", // list of receivers
      subject: "Hello ✔", // Subject line
      text: "Hello world?", // plain text body
  });


  
  console.log("Message sent: %s", info);
  
}

postSendLink();