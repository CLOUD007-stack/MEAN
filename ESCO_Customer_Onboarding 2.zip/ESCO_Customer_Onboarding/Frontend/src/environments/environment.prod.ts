export const environment = {
  production: true,
  server_url: 'https://analytics-dev.tatapower.com/escoCustApi/'
};
