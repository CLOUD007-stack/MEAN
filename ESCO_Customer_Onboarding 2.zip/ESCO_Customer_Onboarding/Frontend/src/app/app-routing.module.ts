import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Auth Guard
import { AuthguardGuard } from './shared/services/authguard.guard';

// Components
import { LayoutsComponent } from './layouts/layouts.component';
import { HomeComponent } from './modules/home/home.component';
import { LoginComponent } from './modules/login/login.component';
import { ForgotPasswordComponent } from './modules/login/forgot-password/forgot-password.component';
import { AdminComponent } from './modules/admin/admin.component';
import { PagenotfoundComponent } from './shared/components/pagenotfound/pagenotfound.component';
import { ListServicesComponent } from './modules/admin/list-services/list-services.component';
import { AddCustomersComponent } from './modules/admin/add-customers/add-customers.component';
import { ListCustomersComponent } from './modules/admin/list-customers/list-customers.component';
import { ListQueriesComponent } from './modules/admin/list-queries/list-queries.component';
import { CustomerComponent } from './modules/customer/customer.component';
import { TestComponent } from './test/test.component';
import { AddCustomerServiceComponent } from './modules/admin/add-customer-service/add-customer-service.component';
import { AddUserComponent } from './modules/admin/add-user/add-user.component';
import { ReportComponent } from './modules/report/report.component';
import { ResetPasswordComponent } from './modules/login/forgot-password/reset-password/reset-password.component';
import { SetPasswordComponent } from './modules/login/set-password/set-password.component';
import { RegisterComponent } from './modules/register/register.component';
import { ListGroupsComponent } from './modules/admin/list-groups/list-groups.component';
import { ListQueryCategoriesComponent } from './modules/admin/list-query-categories/list-query-categories.component';
import { ServicesComponent } from './modules/home/services/services.component';
import { EnquireComponent } from './modules/home/enquire/enquire.component';

// CUSTOMER
import { CustomerLandingComponent } from './modules/customer/customer-landing/customer-landing.component';
import { CustomerQueryComponent } from './modules/customer/customer-query/customer-query.component';
import { ViewCustomerServiceComponent } from './modules/customer/view-customer-service/view-customer-service.component';



const routes: Routes = [
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent,
    // canActivate: [AuthguardGuard]
  },
  {
    path: 'home-service',
    component: ServicesComponent,
    // canActivate: [AuthguardGuard]
  },
  {
    path: 'enquire',
    component: EnquireComponent,
    // canActivate: [AuthguardGuard]
  },
  {
    path: 'register',
    component: RegisterComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
    // canActivate: [AuthguardGuard]
  },
  {
    path: 'test',
    component: TestComponent,
    // canActivate: [AuthguardGuard]
  },
  {
    path: '',
    component: LayoutsComponent,
    children: [
      {
        path: 'admin',
        component: AdminComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'services',
        component: ListServicesComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'groups',
        component: ListGroupsComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'add-customer',
        component: AddCustomersComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'add-customer-service',
        component: AddCustomerServiceComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'add-user',
        component: AddUserComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'list-customer',
        component: ListCustomersComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'queries',
        component: ListQueriesComponent,
        canActivate: [AuthguardGuard]
      },
      {
        path: 'query-category',
        component: ListQueryCategoriesComponent,
        // canActivate: [AuthguardGuard]
      },
      {
        path: 'customer',
        component: CustomerComponent,
        // canActivate: [AuthguardGuard]
      },
      {
        path: 'report',
        component: ReportComponent,
      },
    ]
  },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent,
  },
  {
    path: 'reset-password/:token',
    component: ResetPasswordComponent,
  },
  {
    path: 'set-password',
    component: SetPasswordComponent,
  },
  {
    path: 'customer-landing',
    component: CustomerLandingComponent,
  },
  {
    path: 'view-customer-service',
    component: ViewCustomerServiceComponent,
  },
  {
    path: 'customer-query',
    component: CustomerQueryComponent,
  },
  {
    path: '**',
    component: PagenotfoundComponent,
    // canActivate: [AuthguardGuard]
  },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
