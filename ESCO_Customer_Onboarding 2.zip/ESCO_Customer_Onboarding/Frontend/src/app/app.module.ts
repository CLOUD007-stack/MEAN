import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';

//COMPONENTS
import { AppComponent } from './app.component';
import { LayoutsComponent } from './layouts/layouts.component';
import { HomeComponent } from './modules/home/home.component';
import { ServicesComponent } from './modules/home/services/services.component';
import { EnquireComponent } from './modules/home/enquire/enquire.component';
import { LoginComponent } from './modules/login/login.component';
import { TestComponent } from './test/test.component';
import { ReportComponent } from './modules/report/report.component';
import { ListServicesComponent } from './modules/admin/list-services/list-services.component';
import { ForgotPasswordComponent } from './modules/login/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './modules/login/forgot-password/reset-password/reset-password.component';
import { SetPasswordComponent } from './modules/login/set-password/set-password.component';
import { RegisterComponent } from './modules/register/register.component';
import { ListGroupsComponent } from './modules/admin/list-groups/list-groups.component';
import { DialogHomeComponent } from './shared/components/dialog-home/dialog-home.component';
import { DialogCustomerComponent } from './shared/components/dialog-customer/dialog-customer.component';
import { ListQueryCategoriesComponent } from './modules/admin/list-query-categories/list-query-categories.component';
import { ListQueriesComponent } from './modules/admin/list-queries/list-queries.component';

import { CustomerLandingComponent } from './modules/customer/customer-landing/customer-landing.component';
import { CustomerWelcomeComponent } from './modules/customer/customer-welcome/customer-welcome.component';
import { CustomerQueryComponent } from './modules/customer/customer-query/customer-query.component';
import { CustomerHeaderComponent } from './shared/components/customer-header/customer-header.component';
import { CustomerBackgroundComponent } from './modules/customer/customer-background/customer-background.component';
import { ViewCustomerServiceComponent } from './modules/customer/view-customer-service/view-customer-service.component';

import { LayoutsModule } from './layouts/layouts.module';

 
//MODULES
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CardModule } from "primeng/card";
// import {MatCardModule} from '@angular/material/card';
// import { JwtModule } from '@auth0/angular-jwt';  // JWT auth
import { ToastrModule } from 'ngx-toastr';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Test1Component } from './test/test1/test1.component';
import { Test2Component } from './test/test2/test2.component';




// import { MatDialogModule } from '@angular/material/dialog';




@NgModule({
  declarations: [
    AppComponent,
    // LayoutsComponent,
    HomeComponent,
    ServicesComponent,
    EnquireComponent,
    LoginComponent,
    TestComponent,
    ReportComponent,
    ListServicesComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    SetPasswordComponent,
    RegisterComponent,
    ListGroupsComponent,
    CustomerLandingComponent,
    CustomerWelcomeComponent,
    CustomerQueryComponent,
    CustomerHeaderComponent,
    CustomerBackgroundComponent,
    ViewCustomerServiceComponent,
    ListQueryCategoriesComponent,    
    DialogHomeComponent, 
    DialogCustomerComponent,
    ListQueriesComponent,
    Test1Component,
    Test2Component,   
  ],
  imports: [
    LayoutsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    NgbModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    CardModule,
    MatIconModule,
    MatTabsModule,
    MatDividerModule,
    MatTooltipModule,
    ToastrModule.forRoot({
      timeOut: 4000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }),
    // MatDialogModule,
    // This library provides an HttpInterceptor which automatically attaches a JSON Web Token to HttpClient requests.
    // JwtModule.forRoot({
    //   config: {
    //     tokenGetter: () => {
    //       // console.log(localStorage.getItem('access_token'));
    //       return localStorage.getItem('access_token');
    //     },
    //     allowedDomains: ['http://172.16.208.213:3003'],
    //     disallowedRoutes: ['http://172.16.208.213:3003/api/post/login']
    //     },
    // }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
